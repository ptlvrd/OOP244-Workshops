#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstring>
#include "Perishable.h"
#include "Utils.h"

using namespace std;

namespace sdds {
    Perishable::Perishable() : Item() {
        m_handling = nullptr;
    }

    Perishable::Perishable(const Perishable& other) : Item(other) {
        m_handling = new char[strlen(other.m_handling) + 1];
        strcpy(m_handling, other.m_handling);

        m_expiry = other.m_expiry;
    }

    Perishable& Perishable::operator=(Perishable& other) {
        if (this != &other) {
            Item::operator=(other);

            delete[] m_handling;

            m_handling = new char[strlen(other.m_handling) + 1];
            strcpy(m_handling, other.m_handling);

            m_expiry = other.m_expiry;
        }
        return *this;
    }

    Perishable::~Perishable() {
        delete[] m_handling;
        m_handling = nullptr;
        m_expiry.formatted(false);
    }

    const Date& Perishable::expiry() const {
        return m_expiry;
    }

    int Perishable::readSku(istream& istr) {
        return m_sku = ut.getint(10000, 39999, "SKU: ");
    }

    ofstream& Perishable::save(ofstream& ofstr) const {
        if (m_state) {
            Item::save(ofstr);
            if (m_handling != nullptr) {
                ofstr << m_handling << "\t";
            }
            else {
                ofstr << "\t";
            }
            ofstr << m_expiry.uniqueDateValue() << "\t";
        }
        return ofstr;
    }

    ifstream& Perishable::load(ifstream& ifstr) {
        Item::load(ifstr);

        delete[] m_handling;
        m_handling = nullptr;
        char temp[1000];
        if (ifstr.getline(temp, 1000, '\t') && isalpha(temp[0])) {
            m_handling = new char[strlen(temp) + 1];
            strcpy(m_handling, temp);
        }

        if (ifstr.fail()) {
            m_state = "Input file stream read (perishable) failed!";
            return ifstr;
        }

        ifstr >> m_expiry;
        ifstr.ignore(1000, '\t');
        return ifstr;
    }

    ostream& Perishable::display(ostream& ostr) const {
        if (!m_state) {
            ostr << m_state;
        }
        else {
            if (Item::linear()) {
                Item::display(ostr);
                if (m_handling != nullptr && m_handling[0] != '\0') {
                    ostr << "*";
                }
                else {
                    ostr << " ";
                }
                ostr << m_expiry;
            }
            else {
                ostr << "Perishable ";
                Item::display(ostr);
                ostr << "Expiry date: " << m_expiry << endl;
                if (m_handling != nullptr && m_handling[0] != '\0') {
                    ostr << "Handling Instructions: " << m_handling << endl;
                }
            }
        }
        return ostr;
    }

    istream& Perishable::read(istream& istr) {
        Item::read(istr);

        delete[] m_handling;
        m_handling = nullptr;

        cout << "Expiry date (YYMMDD): ";
        istr >> m_expiry;
        istr.ignore();

        cout << "Handling Instructions, ENTER to skip: ";
        char firstChar = istr.peek();
        if (firstChar != '\n') {
            m_handling = new char[1000];
            istr.getline(m_handling, 1000);
        }
        else {
            istr.ignore();
        }

        if (istr.fail()) {
            m_state = "Perishable console date entry failed!";
        }
        return istr;
    }
}
