/*Author	patel vrundaben vijaykumar
id - 158605220
date 27-11-2023
I have done all the coding by myself and only copied the code
that my professor provided to complete my workshops and assignments.*/
#ifndef SDDS_PERISHABLE_H_
#define SDDS_PERISHABLE_H_
#include "Item.h"
#include "Date.h"

namespace sdds {
	class Perishable : public Item {
	private:
		Date m_expiry;
		char* m_handling;
	public:
		Perishable();
		Perishable(const Perishable& other);
		Perishable& operator=(Perishable& other);
		~Perishable();

		const Date& expiry()const;
		int readSku(istream& istr);
		ofstream& save(ofstream& ofstr) const;
		ifstream& load(ifstream& ifstr);
		ostream& display(ostream& ostr) const;
		istream& read(istream& istr);
	};
}
#endif // !SDDS_PERISHABLE_H_
